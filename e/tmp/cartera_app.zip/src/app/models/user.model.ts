export interface User {
     idusuario: number;
     login: string;
     nombre: string;
    numpol: string;
    passwd: string;
    status: string;
    nivel: string;
    iniciales: string;
 }
 