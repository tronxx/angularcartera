export interface Usuarioregistrado {
    id: number;
    login: string;
    nombre: string;
   token: string;
   numpol: string;
   acceso: string;
}
