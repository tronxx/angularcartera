export interface Poliza {
    fecha: string,
    tda: string,
    status: string,
    bonif: number,
    recar:number,
    impor: number,
    idpoliza: number
}
